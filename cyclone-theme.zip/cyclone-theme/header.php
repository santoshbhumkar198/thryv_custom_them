
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php bloginfo('name'); ?> | <?php wp_title('description'); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo  get_template_directory_uri();?>/assets/css/style.css">
   
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<div class="navbar">
    <div class="logo">
    <?php if (has_custom_logo()) : ?>
    <div class="site-logo">
        <?php the_custom_logo(); ?>
    </div>
<?php else : ?>
    <div class="site-title">
        <a href="<?php echo esc_url(home_url('/')); ?>">
            <?php bloginfo('name'); ?>
        </a>
    </div>
<?php endif; ?>

    </div>
    <div class="nav-links">
    <nav>
    <?php
    wp_nav_menu(array(
        'theme_location' => 'primary',
        'container' => false,
        'menu_class' => 'nav-links',
        
    ));
    ?>
</nav>

    </div>
    <a class="contact-btn" href="<?php echo home_url('/contact'); ?>">Contact Us</a>
</div>
