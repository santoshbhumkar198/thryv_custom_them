const showMoreBtn = document.getElementById("showMoreBtn");
const extraSections = document.querySelectorAll(".extra");

let expanded = false;

showMoreBtn.addEventListener("click", () => {
  extraSections.forEach((section) => {
    section.classList.toggle("hidden");
  });

  showMoreBtn.textContent = expanded ? "Show More" : "Show Less";
  expanded = !expanded;
});

window.addEventListener("DOMContentLoaded", () => {
  extraSections.forEach((section) => section.classList.add("hidden"));
});
// JavaScript to handle show more button functionality
document.addEventListener("DOMContentLoaded", () => {
  const showMrBtn = document.getElementById("showMrBtn");
  const hiddenServices = document.querySelectorAll(".hidden-service");

  let isExpanded = false;

  showMrBtn.addEventListener("click", () => {
    hiddenServices.forEach((service) => {
      service.style.display = isExpanded ? "none" : "block";
    });

    showMrBtn.textContent = isExpanded ? "Show More" : "Show Less";
    isExpanded = !isExpanded;
  });

  // Ensure hidden services are hidden initially
  hiddenServices.forEach((service) => (service.style.display = "none"));
});
