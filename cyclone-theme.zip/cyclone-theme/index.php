<?php get_header(); ?>
<div class="hero">
    <video class="hero-bg-video" 
        autoplay muted playsinline loop 
        src="https://cdn.pixabay.com/video/2021/02/10/64812-510851145_tiny.mp4">
    </video>

    <div class="hero-content">
        <h1><?php echo get_theme_mod('hero_heading', 'Welcome to Our Website'); ?></h1>
        <p><?php echo get_theme_mod('hero_subheading', 'Your subtitle here.'); ?></p>
        <a class="know-more-btn" href="<?php echo esc_url(get_theme_mod('know_more_link', '#')); ?>">Know More →</a>
    </div>
</div>

<?php 
$text_editor_content = get_theme_mod('cyclone_text_editor_setting', 'Default content if not set');
if (!empty($text_editor_content)) {
    echo wp_kses_post($text_editor_content); // Sanitize output
}
?>
    
    <!-- Expertise Section -->
<div class="expertise-container">
    <h2><?php echo esc_html__('Our Expertise', 'cyclone'); ?></h2>

    <div class="expertise-sections">
        <!-- Left Column -->
        <div class="left-column">
            <?php for ($i = 1; $i <= 3; $i++): ?>
                <div class="expertise-section <?php echo ($i > 2) ? 'extra hidden' : ''; ?>">
                    <div class="expertise-title">
                        <?php echo esc_html(get_theme_mod("expertise_title_$i", __("Expertise Title $i", 'cyclone'))); ?>
                    </div>
                    <p><?php echo wp_kses_post(get_theme_mod("expertise_description_$i", __("Description for Expertise $i", 'cyclone'))); ?></p>
                </div>
            <?php endfor; ?>
        </div>

        <!-- Right Column -->
        <div class="right-column">
            <?php for ($i = 4; $i <= 6; $i++): ?>
                <div class="expertise-section <?php echo ($i > 5) ? 'extra hidden' : ''; ?>">
                    <div class="expertise-title">
                        <?php echo esc_html(get_theme_mod("expertise_title_$i", __("Expertise Title $i", 'cyclone'))); ?>
                    </div>
                    <p><?php echo wp_kses_post(get_theme_mod("expertise_description_$i", __("Description for Expertise $i", 'cyclone'))); ?></p>
                </div>
            <?php endfor; ?>
        </div>
    </div>

    <div class="button-container">
        <button class="show-more-btn" id="showMoreBtn">Show More</button>
    </div>
</div>

<!-- Additional Sections -->
<section class="our-work">
    <div class="content">
        <h1><?php echo esc_html(get_theme_mod('our_work_title', __('Our Work', 'cyclone'))); ?></h1>
        <p class="intro-text">
            <?php echo wp_kses_post(get_theme_mod('our_work_intro_text', __('Trusted by high-growth companies, we’re obsessed with delivering results that exceed expectations...', 'cyclone'))); ?>
        </p>
        <div class="work-details">
            <div class="images">
                <img src="<?php echo esc_url(get_theme_mod('mobile_app_image', get_template_directory_uri() . '/assets/images/mobui.jpeg')); ?>" alt="Mobile App UI" class="mockup phone">
                <img src="<?php echo esc_url(get_theme_mod('dashboard_image', get_template_directory_uri() . '/assets/images/dashoardui.jpg')); ?>" alt="Dashboard UI" class="mockup dashboard">
            </div>
            <div class="info">
                <h2><?php echo esc_html(get_theme_mod('case_study_title', __('SnIppIt', 'cyclone'))); ?></h2>
                <p class="description">
                    <?php echo wp_kses_post(get_theme_mod('case_study_description', __('We help you build a thriving B2B ecosystem...', 'cyclone'))); ?>
                </p>
                <a href="<?php echo esc_url(get_theme_mod('case_study_link', '#')); ?>" class="case-study-link">See Case Study →</a>
                <div class="tech-icons">
                    <?php 
                    $tech_items = ['adobe_xd', 'react', 'python'];
                    foreach ($tech_items as $tech) : 
                        // Get icon URL with a fallback to a default image if not set
                        $icon_url = esc_url(get_theme_mod("tech_icon_$tech", get_template_directory_uri() . "/assets/images/$tech.png"));
                        ?>
                        <div class="icon">
                            <img src="<?php echo $icon_url; ?>" alt="<?php echo esc_attr(ucwords(str_replace('_', ' ', $tech))); ?>">
                            <span><?php echo esc_html(ucwords(str_replace('_', ' ', $tech))); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>



<div class="threesection">
    <section class="three-columns">
        <div class="column">
            <img src="<?php echo esc_url(get_theme_mod('column_1_image', get_template_directory_uri() . '/assets/images/team.png')); ?>" alt="Team Icon" class="icon1">
            <h3><?php echo esc_html(get_theme_mod('column_1_title', __('Team', 'cyclone'))); ?></h3>
            <p><?php echo wp_kses_post(get_theme_mod('column_1_description', __('We’ll soak ourselves in your craft, your product and your persona—till the time we’re simply a wing of your own team.', 'cyclone'))); ?></p>
        </div>
        <div class="column">
            <img src="<?php echo esc_url(get_theme_mod('column_2_image', get_template_directory_uri() . '/assets/images/stratergy.png')); ?>" alt="Strategy Icon" class="icon1">
            <h3><?php echo esc_html(get_theme_mod('column_2_title', __('Strategy and Design', 'cyclone'))); ?></h3>
            <p><?php echo wp_kses_post(get_theme_mod('column_2_description', __('We’ll soak ourselves in your craft, your product and your persona—till the time we’re simply a wing of your own team.', 'cyclone'))); ?></p>
        </div>
        <div class="column">
            <img src="<?php echo esc_url(get_theme_mod('column_3_image', get_template_directory_uri() . '/assets/images/execution-512.webp')); ?>" alt="Execution Icon" class="icon1">
            <h3><?php echo esc_html(get_theme_mod('column_3_title', __('Execution', 'cyclone'))); ?></h3>
            <p><?php echo wp_kses_post(get_theme_mod('column_3_description', __('We’ll soak ourselves in your craft, your product and your persona—till the time we’re simply a wing of your own team.', 'cyclone'))); ?></p>
        </div>
    </section>
</div>

<div class="services">
    <section class="services-section">
        <h1><?php echo esc_html(__('Services We Offer', 'cyclone')); ?></h1>

        <div class="services-grid" id="servicesGrid">
            <?php
            // Loop through each service
            for ($i = 1; $i <= 9; $i++) {
                // Retrieve title, description, and image for each service
                $title = get_theme_mod("service_{$i}_title", __('Service Title', 'cyclone'));
                $description = get_theme_mod("service_{$i}_description", __('Service description goes here.', 'cyclone'));
                $image = esc_url(get_theme_mod("service_{$i}_image", get_template_directory_uri() . "/assets/images/default-service-image.jpg"));

                // Display service card only if the title is not empty
                if (!empty($title)) {
                    // Add 'hidden' class to services beyond the first two
                    $extra_class = $i > 6 ? 'hidden-service' : '';
                    echo '<div class="service-card ' . esc_attr($extra_class) . '">';
                    echo '<img src="' . $image . '" alt="' . esc_attr($title) . '">';
                    echo '<h3>' . esc_html($title) . '</h3>';
                    echo '<p>' . wp_kses_post($description) . '</p>';
                    echo '</div>';
                }
            }
            ?>
        </div>

        <button class="show-more" id="showMrBtn">Show More</button>
    </section>
</div>
<div class="stack">
    <section class="stack-section">
        <h1><?php echo get_theme_mod('custom_stack_title', 'Our Stack'); ?></h1>
        <p><?php echo get_theme_mod('custom_stack_description', 'A sleek, modern user interface on one side, seamlessly transitioning into clean code snippets (NodeJS, Laravel, Angular) on the other.'); ?></p>
        <div class="stack-grid">
            <?php
            $technologies = ['Adobe XD', 'React JS', 'Python', 'AWS', 'WordPress', 'MySQL', 'Figma', 'HTML 5', 'CSS 3'];
            foreach ($technologies as $index => $tech) {
                $image = get_theme_mod("stack_image_$index", '');
                $item_name = get_theme_mod("stack_item_$index", $tech);
            ?>
                <div class="stack-item">
                    <?php if ($image): ?>
                        <img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($item_name); ?>">
                    <?php endif; ?>
                    <span><?php echo esc_html($item_name); ?></span>
                </div>
            <?php } ?>
        </div>
    </section>
</div>
<section class="cta-section">
    <div class="cta-content">
        <h1><?php echo get_theme_mod('cta_title', 'Have a Project or an Idea to Discuss?'); ?></h1>
        <p><?php echo get_theme_mod('cta_description', 'Share your project vision. We\'ll guide and build it using the perfect tech stack'); ?></p>
        <a href="#" class="cta-button"><?php echo get_theme_mod('cta_button_text', 'Let’s Talk →'); ?></a>
    </div>
    <div class="cta-logo">
        <?php 
        $logo = get_theme_mod('cta_logo', '');
        if ($logo): ?>
            <img src="<?php echo esc_url($logo); ?>" alt="Thryv TechLabs">
        <?php endif; ?>
    </div>
</section>


<script>

const showMoreBtn = document.getElementById("showMoreBtn");
    const extraSections = document.querySelectorAll(".extra");

    let expanded = false;

    showMoreBtn.addEventListener("click", () => {
        extraSections.forEach((section) => {
            section.classList.toggle("hidden");
        });

        showMoreBtn.textContent = expanded ? "Show More" : "Show Less";
        expanded = !expanded;
    });

    window.addEventListener("DOMContentLoaded", () => {
        extraSections.forEach((section) => section.classList.add("hidden"));
    });
    // JavaScript to handle show more button functionality
    document.addEventListener("DOMContentLoaded", () => {
        const showMrBtn = document.getElementById("showMrBtn");
        const hiddenServices = document.querySelectorAll(".hidden-service");

        let isExpanded = false;

        showMrBtn.addEventListener("click", () => {
            hiddenServices.forEach((service) => {
                service.style.display = isExpanded ? "none" : "block";
            });

            showMrBtn.textContent = isExpanded ? "Show More" : "Show Less";
            isExpanded = !isExpanded;
        });

        // Ensure hidden services are hidden initially
        hiddenServices.forEach((service) => service.style.display = "none");
    });


</script>


<?php get_footer(); ?>
