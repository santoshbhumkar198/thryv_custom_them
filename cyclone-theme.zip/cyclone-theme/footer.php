<footer class="footer">
    <div class="footer-content">
        <div class="footer-left">
            <p><?php echo esc_html(get_theme_mod('footer_text', 'Thryv TechLabs')); ?></p>
        </div>
        <div class="footer-icons">
            <?php
            $social_platforms = ['facebook', 'twitter', 'linkedin', 'instagram', 'youtube'];
            foreach ($social_platforms as $platform) {
                $icon = get_theme_mod("footer_{$platform}_icon", get_template_directory_uri() . "/assets/images/{$platform}.png");
                $url = get_theme_mod("footer_{$platform}_url", "#");
                echo '<a href="' . esc_url($url) . '" target="_blank">
                        <img src="' . esc_url($icon) . '" alt="' . ucfirst($platform) . '">
                      </a>';
            }
            ?>
        </div>
        <div class="footer-contact">
            <p>📞 <?php echo esc_html(get_theme_mod('footer_phone', '+91 9898596999')); ?></p>
            <p>✉️ <a href="mailto:<?php echo esc_html(get_theme_mod('footer_email', 'info@thryvtechlabs.com')); ?>">
                <?php echo esc_html(get_theme_mod('footer_email', 'info@thryvtechlabs.com')); ?>
            </a></p>
            <p>🌐 <a href="<?php echo esc_url(get_theme_mod('footer_website', 'https://www.thryvtechlabs.com')); ?>" target="_blank">
                <?php echo esc_url(get_theme_mod('footer_website', 'https://www.thryvtechlabs.com')); ?>
            </a></p>
        </div>
    </div>
    <div class="footer-copyright">
        <p>Copyright © 2024 - 2025 all rights reserved.</p>
    </div>
</footer>
