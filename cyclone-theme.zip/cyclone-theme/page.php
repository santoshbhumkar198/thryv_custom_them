<?php

get_header();
the_post();
?>




<?php

get_footer();
?>