<?php
/*
Template Name: Our Work
*/
get_header(); // Include the header
?>

<div class="page-wrapper">
    <!-- Page Title -->
    <h1 class="page-title"><?php the_title(); ?></h1>

    <!-- Featured Image -->
    <?php if (has_post_thumbnail()) : ?>
        <div class="featured-image">
            <?php the_post_thumbnail('full'); // Display the full-size featured image ?>
        </div>
    <?php endif; ?>

    <!-- Page Content -->
    <div class="page-content">
        <?php
        if (have_posts()) :
            while (have_posts()) : the_post();
                the_content(); // Display the content
            endwhile;
        else :
            echo '<p>No content found.</p>';
        endif;
        ?>
    </div>
</div>

<?php get_footer(); // Include the footer ?>

