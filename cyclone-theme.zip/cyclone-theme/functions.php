    <?php
    // Enable theme features
    function cyclone_theme_setup() {
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        register_nav_menus(array(
            'primary' => __('Primary Menu', 'cyclone-theme'),
        
        ));
    }
    add_action('after_setup_theme', 'cyclone_theme_setup');

    function mytheme_custom_logo_setup() {
        add_theme_support('custom-logo', array(
            'height'      => 100,
            'width'       => 400,
            'flex-height' => true,
            'flex-width'  => true,
        ));
    }
    add_action('after_setup_theme', 'mytheme_custom_logo_setup');



    function cyclone_theme_text_setup() {
        add_theme_support('custom-logo');
        add_theme_support('post-thumbnails');
    }
    add_action('after_setup_theme', 'cyclone_theme_text_setup');

    // Register Customizer Settings
    function cyclone_customize_register($wp_customize) {
        

    // Add settings for different elements
    $wp_customize->add_setting( 'header_text', array(
        'default'    => __( 'Default Header Text', 'cyclone-theme' ),
        'sanitize_callback' => 'sanitize_text_field',
    ) );

    // Add a control for header text
    $wp_customize->add_control( 'header_text_control', array(
        'label'      => __( 'Header Text', 'cyclone-theme' ),
        'section'    => 'cyclone_theme_section',
        'settings'   => 'header_text',
        'type'       => 'text',
    ) );

        // Add Section for Hero Section
        $wp_customize->add_section('hero_section', array(
            'title'    => __('Hero Section', 'cyclone'),
            'priority' => 20,
        ));

        // Add settings for Hero Heading
        $wp_customize->add_setting('hero_heading', array(
            'default' => __('Welcome to Our Website', 'cyclone'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('hero_heading', array(
            'label' => __('Hero Heading', 'cyclone'),
            'section' => 'hero_section',
            'type' => 'text',
        ));

        // Add settings for Hero Subheading
        $wp_customize->add_setting('hero_subheading', array(
            'default' => __('Your subtitle here.', 'cyclone'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control('hero_subheading', array(
            'label' => __('Hero Subheading', 'cyclone'),
            'section' => 'hero_section',
            'type' => 'text',
        ));

        // Add settings for Know More Link
        $wp_customize->add_setting('know_more_link', array(
            'default' => '#',
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control('know_more_link', array(
            'label' => __('Know More Link', 'cyclone'),
            'section' => 'hero_section',
            'type' => 'url',
        ));

        // Add settings for Text Editor Content
        $wp_customize->add_setting('cyclone_text_editor_setting', array(
            'default' => __('Default content if not set', 'cyclone'),
            'sanitize_callback' => 'wp_kses_post',
        ));
        $wp_customize->add_control('cyclone_text_editor_setting', array(
            'label' => __('Text Editor Content', 'cyclone'),
            'section' => 'hero_section',
            'type' => 'textarea',
        ));
    
// Expertise Section
     $wp_customize->add_section('expertise_section', array(
    'title'    => __('Expertise Section', 'cyclone'),
    'priority' => 30,
));

// Adding settings and controls for Expertise Titles and Descriptions
for ($i = 1; $i <= 6; $i++) {
    // Expertise Title
    $wp_customize->add_setting("expertise_title_$i", array(
        'default'           => __("Expertise Title $i", 'cyclone'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control("expertise_title_$i", array(
        'label'   => __("Expertise Title $i", 'cyclone'),
        'section' => 'expertise_section',
        'type'    => 'text',
    ));

    // Expertise Description
    $wp_customize->add_setting("expertise_description_$i", array(
        'default'           => __("Description for Expertise $i", 'cyclone'),
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control("expertise_description_$i", array(
        'label'   => __("Expertise Description $i", 'cyclone'),
        'section' => 'expertise_section',
        'type'    => 'textarea',
    ));
}
// Add Section for Our Work
$wp_customize->add_section('our_work_section', array(
    'title'    => __('Our Work Section', 'cyclone'),
    'priority' => 30,
));
    // Our Work Title
    $wp_customize->add_setting('our_work_title', array(
        'default' => __('Our Work', 'cyclone'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('our_work_title', array(
        'label' => __('Our Work Title', 'cyclone'),
        'section' => 'our_work_section',
        'type' => 'text',
    ));

    // Intro Text
    $wp_customize->add_setting('our_work_intro_text', array(
        'default' => __('Trusted by high-growth companies, we’re obsessed with delivering results that exceed expectations...', 'cyclone'),
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('our_work_intro_text', array(
        'label' => __('Intro Text', 'cyclone'),
        'section' => 'our_work_section',
        'type' => 'textarea',
    ));

    // Case Study Title
    $wp_customize->add_setting('case_study_title', array(
        'default' => __('SnIppIt', 'cyclone'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('case_study_title', array(
        'label' => __('Case Study Title', 'cyclone'),
        'section' => 'our_work_section',
        'type' => 'text',
    ));

    // Case Study Description
    $wp_customize->add_setting('case_study_description', array(
        'default' => __('We help you build a thriving B2B ecosystem...', 'cyclone'),
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('case_study_description', array(
        'label' => __('Case Study Description', 'cyclone'),
        'section' => 'our_work_section',
        'type' => 'textarea',
    ));

    // Case Study Link
    $wp_customize->add_setting('case_study_link', array(
        'default' => '#',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control('case_study_link', array(
        'label' => __('Case Study Link', 'cyclone'),
        'section' => 'our_work_section',
        'type' => 'url',
    ));

    // Image Uploads
    $wp_customize->add_setting('mobile_app_image', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'mobile_app_image', array(
        'label' => __('Mobile App Image', 'cyclone'),
        'section' => 'our_work_section',
        'settings' => 'mobile_app_image',
    )));

    $wp_customize->add_setting('dashboard_image', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'dashboard_image', array(
        'label' => __('Dashboard Image', 'cyclone'),
        'section' => 'our_work_section',
        'settings' => 'dashboard_image',
    )));

    // Technology Icons
    $tech_items = ['adobe_xd', 'react', 'python'];
    foreach ($tech_items as $tech) {
        $wp_customize->add_setting("tech_icon_$tech", array(
            'default' => get_template_directory_uri() . "/assets/images/$tech.png",
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "tech_icon_$tech", array(
            'label' => __(ucwords(str_replace('_', ' ', $tech)), 'cyclone'),
            'section' => 'our_work_section',
            'settings' => "tech_icon_$tech",
        )));
    }

    // Add Section for Three Columns
    $wp_customize->add_section('three_columns_section', array(
        'title'    => __('Three Columns Section', 'cyclone'),
        'priority' => 30,
    ));

    // Column 1 Settings
    $wp_customize->add_setting('column_1_title', array(
        'default' => __('Team', 'cyclone'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('column_1_title', array(
        'label' => __('Column 1 Title', 'cyclone'),
        'section' => 'three_columns_section',
        'type' => 'text',
    ));

    $wp_customize->add_setting('column_1_description', array(
        'default' => __('We’ll soak ourselves in your craft, your product and your persona—till the time we’re simply a wing of your own team.', 'cyclone'),
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('column_1_description', array(
        'label' => __('Column 1 Description', 'cyclone'),
        'section' => 'three_columns_section',
        'type' => 'textarea',
    ));

    $wp_customize->add_setting('column_1_image', array(
        'default' => get_template_directory_uri() . '/assets/images/team.png',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'column_1_image', array(
        'label' => __('Column 1 Image', 'cyclone'),
        'section' => 'three_columns_section',
        'settings' => 'column_1_image',
    )));

    // Column 2 Settings
    $wp_customize->add_setting('column_2_title', array(
        'default' => __('Strategy and Design', 'cyclone'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('column_2_title', array(
        'label' => __('Column 2 Title', 'cyclone'),
        'section' => 'three_columns_section',
        'type' => 'text',
    ));

    $wp_customize->add_setting('column_2_description', array(
        'default' => __('We’ll soak ourselves in your craft, your product and your persona—till the time we’re simply a wing of your own team.', 'cyclone'),
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('column_2_description', array(
        'label' => __('Column 2 Description', 'cyclone'),
        'section' => 'three_columns_section',
        'type' => 'textarea',
    ));

    $wp_customize->add_setting('column_2_image', array(
        'default' => get_template_directory_uri() . '/assets/images/stratergy.png',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'column_2_image', array(
        'label' => __('Column 2 Image', 'cyclone'),
        'section' => 'three_columns_section',
        'settings' => 'column_2_image',
    )));

    // Column 3 Settings
    $wp_customize->add_setting('column_3_title', array(
        'default' => __('Execution', 'cyclone'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('column_3_title', array(
        'label' => __('Column 3 Title', 'cyclone'),
        'section' => 'three_columns_section',
        'type' => 'text',
    ));

    $wp_customize->add_setting('column_3_description', array(
        'default' => __('We’ll soak ourselves in your craft, your product and your persona—till the time we’re simply a wing of your own team.', 'cyclone'),
        'sanitize_callback' => 'wp_kses_post',
    ));
    $wp_customize->add_control('column_3_description', array(
        'label' => __('Column 3 Description', 'cyclone'),
        'section' => 'three_columns_section',
        'type' => 'textarea',
    ));

    $wp_customize->add_setting('column_3_image', array(
        'default' => get_template_directory_uri() . '/assets/images/execution-512.webp',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'column_3_image', array(
        'label' => __('Column 3 Image', 'cyclone'),
        'section' => 'three_columns_section',
        'settings' => 'column_3_image',
    )));

    // Add Section for Services
    $wp_customize->add_section('services_section', array(
        'title'    => __('Services We Offer', 'cyclone'),
        'priority' => 30,
    ));

    // Create settings and controls for 6 services
    for ($i = 1; $i <= 6; $i++) {
        // Service Title
        $wp_customize->add_setting("service_{$i}_title", array(
            'default' => __('Service Title', 'cyclone'),
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control("service_{$i}_title", array(
            'label' => __("Service {$i} Title", 'cyclone'),
            'section' => 'services_section',
            'type' => 'text',
        ));

        // Service Description
        $wp_customize->add_setting("service_{$i}_description", array(
            'default' => __('Service description goes here.', 'cyclone'),
            'sanitize_callback' => 'wp_kses_post',
        ));
        $wp_customize->add_control("service_{$i}_description", array(
            'label' => __("Service {$i} Description", 'cyclone'),
            'section' => 'services_section',
            'type' => 'textarea',
        ));

        // Service Image
        $wp_customize->add_setting("service_{$i}_image", array(
            'default' => get_template_directory_uri() . "/assets/images/default-service-image.jpg", // Change to a default image path
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "service_{$i}_image", array(
            'label' => __("Service {$i} Image", 'cyclone'),
            'section' => 'services_section',
            'settings' => "service_{$i}_image",
        )));
    }

        // Footer Text Setting
        $wp_customize->add_setting('footer_text', [
            'default' => 'Thryv TechLabs',
            'sanitize_callback' => 'sanitize_text_field',
        ]);
        $wp_customize->add_control('footer_text', [
            'label' => __('Footer Text', 'cyclone'),
            'section' => 'footer_section',
            'type' => 'text',
        ]);

        // Social Icons and URLs
        $social_platforms = ['facebook', 'twitter', 'linkedin', 'instagram', 'youtube'];
        foreach ($social_platforms as $platform) {
            // URL Setting
            $wp_customize->add_setting("footer_{$platform}_url", [
                'default' => '#',
                'sanitize_callback' => 'esc_url_raw',
            ]);
            $wp_customize->add_control("footer_{$platform}_url", [
                'label' => ucfirst($platform) . ' URL',
                'section' => 'footer_section',
                'type' => 'url',
            ]);

            // Icon Image Setting
            $wp_customize->add_setting("footer_{$platform}_icon", [
                'default' => get_template_directory_uri() . "/assets/images/{$platform}.png",
                'sanitize_callback' => 'esc_url_raw',
            ]);
            $wp_customize->add_control(new WP_Customize_Image_Control(
                $wp_customize,
                "footer_{$platform}_icon",
                [
                    'label' => ucfirst($platform) . ' Icon',
                    'section' => 'footer_section',
                    'settings' => "footer_{$platform}_icon",
                ]
            ));
        }

        // Contact Information
        $wp_customize->add_setting('footer_phone', [
            'default' => '+91 9898596999',
            'sanitize_callback' => 'sanitize_text_field',
        ]);
        $wp_customize->add_control('footer_phone', [
            'label' => __('Phone Number', 'cyclone'),
            'section' => 'footer_section',
            'type' => 'text',
        ]);

        $wp_customize->add_setting('footer_email', [
            'default' => 'info@thryvtechlabs.com',
            'sanitize_callback' => 'sanitize_email',
        ]);
        $wp_customize->add_control('footer_email', [
            'label' => __('Email Address', 'cyclone'),
            'section' => 'footer_section',
            'type' => 'email',
        ]);

        $wp_customize->add_setting('footer_website', [
            'default' => 'https://www.thryvtechlabs.com',
            'sanitize_callback' => 'esc_url_raw',
        ]);
        $wp_customize->add_control('footer_website', [
            'label' => __('Website URL', 'cyclone'),
            'section' => 'footer_section',
            'type' => 'url',
        ]);

        // Add Footer Section in Customizer
        $wp_customize->add_section('footer_section', [
            'title' => __('Footer Settings', 'cyclone'),
            'priority' => 30,
        ]);
    // Add a new section for the Stack settings
    $wp_customize->add_section('our_stack_section', array(
        'title' => __('Our Stack', 'cyclone-theme'),
        'priority' => 30, // Adjust priority as needed
    ));

    // Stack Section Title
    $wp_customize->add_setting('custom_stack_title', array(
        'default' => 'Our Stack',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('custom_stack_title', array(
        'label' => __('Stack Section Title', 'cyclone-theme'),
        'section' => 'our_stack_section',
        'type' => 'text',
    ));

    // Stack Section Description
    $wp_customize->add_setting('custom_stack_description', array(
        'default' => 'A sleek, modern user interface on one side, seamlessly transitioning into clean code snippets (NodeJS, Laravel, Angular) on the other.',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('custom_stack_description', array(
        'label' => __('Stack Section Description', 'cyclone-theme'),
        'section' => 'our_stack_section',
        'type' => 'textarea',
    ));

    // Stack Items
    $technologies = ['Adobe XD', 'React JS', 'Python', 'AWS', 'WordPress', 'MySQL', 'Figma', 'HTML 5', 'CSS 3'];
    
    foreach ($technologies as $index => $tech) {
        // Text setting
        $wp_customize->add_setting("stack_item_$index", array(
            'default' => $tech,
            'sanitize_callback' => 'sanitize_text_field',
        ));
        $wp_customize->add_control("stack_item_$index", array(
            'label' => __("Stack Item $index", 'cyclone-theme'),
            'section' => 'our_stack_section',
            'type' => 'text',
        ));

        // Image setting
        $wp_customize->add_setting("stack_image_$index", array(
            'default' => '', // Default image URL
            'sanitize_callback' => 'esc_url_raw',
        ));
        $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "stack_image_$index", array(
            'label' => __("Image for $tech", 'cyclone-theme'),
            'section' => 'our_stack_section',
            'settings' => "stack_image_$index",
        )));
    }


    // Add a new section for the CTA settings
    $wp_customize->add_section('cta_section', array(
        'title' => __('Call to Action', 'cyclone-theme'),
        'priority' => 30,
    ));

    // CTA Section Title
    $wp_customize->add_setting('cta_title', array(
        'default' => 'Have a Project or an Idea to Discuss?',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cta_title', array(
        'label' => __('CTA Section Title', 'cyclone-theme'),
        'section' => 'cta_section',
        'type' => 'text',
    ));

    // CTA Section Description
    $wp_customize->add_setting('cta_description', array(
        'default' => 'Share your project vision. We\'ll guide and build it using the perfect tech stack',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    $wp_customize->add_control('cta_description', array(
        'label' => __('CTA Section Description', 'cyclone-theme'),
        'section' => 'cta_section',
        'type' => 'textarea',
    ));

    // CTA Button Text
    $wp_customize->add_setting('cta_button_text', array(
        'default' => 'Let’s Talk →',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    $wp_customize->add_control('cta_button_text', array(
        'label' => __('CTA Button Text', 'cyclone-theme'),
        'section' => 'cta_section',
        'type' => 'text',
    ));

    // CTA Logo
    $wp_customize->add_setting('cta_logo', array(
        'default' => '', // Default logo URL
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'cta_logo', array(
        'label' => __('CTA Logo', 'cyclone-theme'),
        'section' => 'cta_section',
        'settings' => 'cta_logo',
    )));
    }

    add_action('customize_register', 'cyclone_customize_register');
    ?>


